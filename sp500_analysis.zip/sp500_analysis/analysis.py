"""
S&P 500 Sector & Valuation Analysis
------------------------------------
Analyzes S&P 500 constituent companies: valuation multiples (P/E, P/B, P/S),
dividend yield, market cap and EBITDA margin, broken down by GICS sector.

Data sources (public, open-data license):
- data/constituents.csv          -> company metadata (sector, sub-industry, HQ)
- data/financials.csv            -> valuation & fundamental metrics
Source: github.com/datasets (community-maintained financial open-data project)

Author: [Your Name]
"""

import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
pd.set_option("display.width", 120)

# ---------------------------------------------------------------------------
# 1. LOAD & CLEAN
# ---------------------------------------------------------------------------
fin = pd.read_csv("data/financials.csv")
meta = pd.read_csv("data/constituents.csv")

# Standardize column names for easier SQL use
fin = fin.rename(columns={
    "Price/Earnings": "pe_ratio",
    "Dividend Yield": "dividend_yield",
    "Earnings/Share": "eps",
    "Market Cap": "market_cap",
    "Price/Sales": "price_sales",
    "Price/Book": "price_book",
})
meta = meta.rename(columns={"GICS Sector": "gics_sector", "GICS Sub-Industry": "gics_subindustry"})

df = fin.merge(meta[["Symbol", "gics_sector", "gics_subindustry"]], on="Symbol", how="left")

# Drop companies missing core valuation data (e.g. recent spin-offs / dual share classes)
before = len(df)
df = df.dropna(subset=["pe_ratio", "market_cap", "gics_sector"])
# Remove clear data errors: negative/absurd P/E from one-off accounting losses
df = df[(df["pe_ratio"] > 0) & (df["pe_ratio"] < 200)]
after = len(df)
print(f"Loaded {before} companies, kept {after} after cleaning "
      f"({before - after} removed: missing data or non-meaningful P/E).")

df["market_cap_bn"] = df["market_cap"] / 1e9
df["ebitda_bn"] = df["EBITDA"] / 1e9
df["dividend_yield_pct"] = df["dividend_yield"] * 100

# ---------------------------------------------------------------------------
# 2. SQL ANALYSIS (SQLite in-memory — demonstrates SQL, not just pandas)
# ---------------------------------------------------------------------------
conn = sqlite3.connect(":memory:")
df.to_sql("companies", conn, index=False, if_exists="replace")

queries = {}

queries["sector_summary"] = """
SELECT
    gics_sector,
    COUNT(*)                       AS n_companies,
    ROUND(AVG(pe_ratio), 1)        AS avg_pe,
    ROUND(AVG(dividend_yield_pct), 2) AS avg_div_yield_pct,
    ROUND(SUM(market_cap_bn), 0)   AS total_market_cap_bn
FROM companies
GROUP BY gics_sector
ORDER BY total_market_cap_bn DESC;
"""

queries["negative_book_equity"] = """
-- Companies with negative Price/Book => negative shareholder equity.
-- Usually the result of aggressive share buybacks / leveraged balance sheets,
-- NOT a data error. Worth flagging separately rather than averaging blindly.
SELECT Symbol, Name, gics_sector, price_book, market_cap_bn
FROM companies
WHERE price_book < 0
ORDER BY price_book ASC;
"""

queries["top15_market_cap"] = """
SELECT Symbol, Name, gics_sector, market_cap_bn, pe_ratio
FROM companies
ORDER BY market_cap_bn DESC
LIMIT 15;
"""

queries["value_candidates"] = """
-- "Value" screen: below-median P/E, above-median dividend yield
SELECT Symbol, Name, gics_sector, pe_ratio, dividend_yield_pct, market_cap_bn
FROM companies
WHERE pe_ratio < (SELECT AVG(pe_ratio) FROM companies)
  AND dividend_yield_pct > (SELECT AVG(dividend_yield_pct) FROM companies)
ORDER BY dividend_yield_pct DESC
LIMIT 15;
"""

queries["sector_concentration"] = """
SELECT
    gics_sector,
    ROUND(SUM(market_cap_bn), 0) AS sector_cap_bn,
    ROUND(100.0 * SUM(market_cap_bn) / (SELECT SUM(market_cap_bn) FROM companies), 1) AS pct_of_index
FROM companies
GROUP BY gics_sector
ORDER BY sector_cap_bn DESC;
"""

results = {name: pd.read_sql(q, conn) for name, q in queries.items()}

for name, res in results.items():
    print(f"\n=== {name} ===")
    print(res.to_string(index=False))

# ---------------------------------------------------------------------------
# 3. VISUALIZATIONS
# ---------------------------------------------------------------------------

# Chart 1: Average P/E by sector
plt.figure(figsize=(10, 6))
sector_pe = results["sector_summary"].sort_values("avg_pe")
sns.barplot(data=sector_pe, y="gics_sector", x="avg_pe", hue="gics_sector", palette="viridis", legend=False)
plt.title("Average P/E Ratio by GICS Sector (S&P 500)")
plt.xlabel("Average P/E Ratio")
plt.ylabel("")
plt.tight_layout()
plt.savefig("charts/01_avg_pe_by_sector.png", dpi=150)
plt.close()

# Chart 2: Sector market cap concentration (% of index)
plt.figure(figsize=(10, 6))
conc = results["sector_concentration"].sort_values("pct_of_index")
sns.barplot(data=conc, y="gics_sector", x="pct_of_index", hue="gics_sector", palette="mako", legend=False)
plt.title("Sector Weight in the S&P 500 (% of Total Market Cap)")
plt.xlabel("% of Index Market Cap")
plt.ylabel("")
plt.tight_layout()
plt.savefig("charts/02_sector_concentration.png", dpi=150)
plt.close()

# Chart 3: P/E vs Dividend Yield scatter, colored by sector
plt.figure(figsize=(11, 7))
top_sectors = df["gics_sector"].value_counts().head(8).index
plot_df = df[df["gics_sector"].isin(top_sectors)]
sns.scatterplot(data=plot_df, x="pe_ratio", y="dividend_yield_pct",
                 hue="gics_sector", size="market_cap_bn", sizes=(20, 400), alpha=0.7)
plt.title("Valuation vs. Income: P/E Ratio vs Dividend Yield")
plt.xlabel("P/E Ratio")
plt.ylabel("Dividend Yield (%)")
plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
plt.tight_layout()
plt.savefig("charts/03_pe_vs_dividend_yield.png", dpi=150)
plt.close()

# Chart 4: Top 15 companies by market cap
plt.figure(figsize=(10, 7))
top15 = results["top15_market_cap"].sort_values("market_cap_bn")
sns.barplot(data=top15, y="Name", x="market_cap_bn", hue="Name", palette="crest", legend=False)
plt.title("Top 15 S&P 500 Companies by Market Capitalization")
plt.xlabel("Market Cap ($ Billion)")
plt.ylabel("")
plt.tight_layout()
plt.savefig("charts/04_top15_market_cap.png", dpi=150)
plt.close()

# Chart 5: Distribution of P/E ratios
plt.figure(figsize=(9, 5.5))
sns.histplot(df["pe_ratio"], bins=40, kde=True, color="steelblue")
plt.axvline(df["pe_ratio"].mean(), color="red", linestyle="--", label=f"Mean = {df['pe_ratio'].mean():.1f}")
plt.axvline(df["pe_ratio"].median(), color="orange", linestyle="--", label=f"Median = {df['pe_ratio'].median():.1f}")
plt.title("Distribution of P/E Ratios Across S&P 500")
plt.xlabel("P/E Ratio")
plt.legend()
plt.tight_layout()
plt.savefig("charts/05_pe_distribution.png", dpi=150)
plt.close()

# Chart 6: Price/Book by sector (boxplot)
plt.figure(figsize=(11, 6))
order = df.groupby("gics_sector")["price_book"].median().sort_values().index
sns.boxplot(data=df, x="price_book", y="gics_sector", order=order, hue="gics_sector", palette="flare", showfliers=False, legend=False)
plt.title("Price/Book Ratio Distribution by Sector")
plt.xlabel("Price/Book")
plt.ylabel("")
plt.tight_layout()
plt.savefig("charts/06_price_book_by_sector.png", dpi=150)
plt.close()

print("\nAll charts saved to charts/")

# ---------------------------------------------------------------------------
# 4. EXPORT SUMMARY TO EXCEL (for stakeholders who prefer Excel over code)
# ---------------------------------------------------------------------------
with pd.ExcelWriter("exports/sp500_analysis_summary.xlsx", engine="openpyxl") as writer:
    results["sector_summary"].to_excel(writer, sheet_name="Sector Summary", index=False)
    results["top15_market_cap"].to_excel(writer, sheet_name="Top 15 by Market Cap", index=False)
    results["value_candidates"].to_excel(writer, sheet_name="Value Candidates", index=False)
    results["sector_concentration"].to_excel(writer, sheet_name="Sector Concentration", index=False)
    results["negative_book_equity"].to_excel(writer, sheet_name="Negative Book Equity", index=False)
    df[["Symbol", "Name", "gics_sector", "pe_ratio", "dividend_yield_pct",
        "price_book", "market_cap_bn"]].to_excel(writer, sheet_name="Raw Data (cleaned)", index=False)

print("Excel summary saved to exports/sp500_analysis_summary.xlsx")

conn.close()
