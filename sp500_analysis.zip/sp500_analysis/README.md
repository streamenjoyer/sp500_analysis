# S&P 500 Sector & Valuation Analysis

A data analysis project examining valuation multiples, dividend yield, and market
capitalization across all S&P 500 constituent companies, broken down by GICS sector.

**Skills demonstrated:** SQL (via SQLite), Python/pandas data cleaning, data
visualization (matplotlib/seaborn), Excel reporting for non-technical stakeholders.

---

## Business question

*How does the market value different sectors of the US economy, and where might
"value" opportunities (low valuation + high income) be hiding?*

This is the kind of question a business/financial analyst gets asked regularly:
not "build me a model" but "help me understand what's going on in the data and
tell me something useful."

## Data

| File | Description | Source |
|---|---|---|
| `data/constituents.csv` | Company name, GICS sector/sub-industry, HQ | [datasets/s-and-p-500-companies](https://github.com/datasets/s-and-p-500-companies) (open data, CC0) |
| `data/financials.csv` | Price, P/E, dividend yield, market cap, EBITDA, P/B, P/S | [datasets/s-and-p-500-companies-financials](https://github.com/datasets/s-and-p-500-companies-financials) (open data, sourced via Yahoo Finance) |

Both are community-maintained, publicly licensed datasets, refreshed regularly —
a realistic stand-in for the kind of external market data an analyst pulls into
a real project.

## Method

1. **Clean:** merge the two datasets on ticker symbol, drop rows with missing core
   fields, and remove non-meaningful P/E ratios (negative or >200 — usually
   one-off accounting losses that distort averages rather than reflect valuation).
   429 of 503 companies passed cleaning.
2. **Analyze with SQL:** load the cleaned data into an in-memory SQLite database
   and run aggregation queries (`GROUP BY`, subqueries, ranking) — see
   `analysis.py` for the actual SQL.
3. **Visualize:** six charts covering sector valuation, index concentration,
   and the P/E-vs-yield trade-off.
4. **Export:** a stakeholder-friendly Excel workbook with the same tables, for
   people who'd rather open a spreadsheet than read code.

## Key findings

- **Information Technology dominates the index**, at ~36% of total S&P 500
  market cap — more than double the next largest sector (Communication
  Services, ~12%). This concentration is itself a risk factor worth flagging
  to anyone benchmarking against the index.
- **Real Estate and Materials trade at the highest average P/E** (39–45x),
  while **Financials trade cheapest** (~19x) — consistent with the market
  pricing in higher growth expectations for the former and treating banks as
  mature, capital-intensive businesses.
- **A "value screen"** (below-average P/E *and* above-average dividend yield)
  surfaces familiar defensive names — Verizon, AT&T, Altria, Pfizer — mostly
  from Telecom, Consumer Staples, and Health Care. This is a real, simple
  version of the kind of screen used in equity research.
- **34 companies have negative Price/Book ratios**, meaning negative
  shareholder equity (McDonald's, Starbucks, AutoZone, Dell among them). This
  isn't a data error — it's the result of years of aggressive share buybacks
  funded by debt. Averaging Price/Book without flagging these separately
  would have quietly produced a nonsense sector average (this is called out
  explicitly in `analysis.py` rather than silently skewing the numbers).

## Files

```
project/
├── analysis.py                          # main script: clean -> SQL -> charts -> Excel
├── data/
│   ├── constituents.csv
│   └── financials.csv
├── charts/
│   ├── 01_avg_pe_by_sector.png
│   ├── 02_sector_concentration.png
│   ├── 03_pe_vs_dividend_yield.png
│   ├── 04_top15_market_cap.png
│   ├── 05_pe_distribution.png
│   └── 06_price_book_by_sector.png
└── exports/
    └── sp500_analysis_summary.xlsx      # same findings, Excel format
```

## How to run

```bash
pip install pandas matplotlib seaborn openpyxl
python analysis.py
```

## Notes / next steps

- Snapshot data (single point in time) — a natural extension would be pulling
  historical prices to analyze trends, not just levels.
- Could add: sector rotation over time, correlation between valuation and
  actual earnings growth, or a simple scoring model for the "value screen."

---
*This project uses publicly available financial data for educational/portfolio
purposes and is not investment advice.*
